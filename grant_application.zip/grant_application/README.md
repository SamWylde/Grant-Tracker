# Grant Application Tracker

A lightweight SaaS for small and rural nonprofits to **discover** grants, **track**
applications, and **never miss deadlines**.

This repository contains a scaffolded implementation of the Grant Application
Tracker described in our product specification.  The goal of this scaffold is
to provide a starting point for building the full‑featured service.  It
includes database migrations, API route stubs, configuration templates,
email/SMS templates and a security checklist.  The marketing site
contained in the original repository is intentionally left out to keep this
scaffold focused on the core application logic.

> MVP focus: federal grants (Grants.gov) + save/track pipeline +
> multi‑deadline reminders + calendar integration and light collaboration.

---

## ✨ Features (MVP)

* **Discover**: Filter federal opportunities by state, category, due date and
  amount via the `/api/grants` endpoint.
* **Save & Track**: Pipeline stages (Researching → Drafting → Submitted →
  Awarded/Declined), notes and attachments are stored via the
  `/api/org-grants` routes.
* **Deadlines**: LOI/Application/Report milestones with **T‑30/14/7/3/1 + day‑of**
  reminders scheduled by the reminder job (`/api/jobs/reminders`).
* **Calendar**: Org‑level **ICS feed** (secret URL) and **Google Calendar** push
  integration.
* **Collaboration**: Unlimited users per org, assignees, task checklists and a
  “My Tasks” query.
* **Import**: CSV importer from an existing spreadsheet (not yet implemented
  in this scaffold).

> Post‑MVP ideas: recurring report RRULEs, templates (LOI/budget),
> private/foundation discovery partners, funder fit scoring, org analytics.

---

## 🧭 Project Goals

* **Audience**: Small nonprofits (<$1M budgets) with limited staff and no
  dedicated grant officer.
* **Outcome**: Reduce missed deadlines; increase submissions; centralize
  tracking.
* **North Star**: percentage of deadlines met and number of submissions per
  quarter per org.

---

## 🏗️ Architecture

The scaffold uses the following stack:

* **Frontend**: Next.js (App Router, TypeScript).  API routes live under
  `app/api` and can be deployed to Vercel or any Node.js runtime.
* **Backend/DB**: Supabase (Postgres, Auth, Storage, RLS).  Database
  migrations are provided in `supabase/migrations`.
* **Jobs**: Vercel Cron or Supabase Scheduled Functions.  The reminder job is
  implemented in `app/api/jobs/reminders`.
* **Email**: Postmark (or SendGrid) – templates live under `templates/emails`.
* **SMS**: Twilio (Pro plan) – templates live under `templates/sms`.
* **Payments**: Stripe integration with sample checkout route (`/api/checkout/session`).
* **Calendar**: An iCalendar feed (`/api/orgs/:orgId/calendar.ics`) and Google
  Calendar OAuth callback route.
* **Observability**: Sentry and PostHog/GA4 hooks can be added as needed.

Alternate stacks (e.g. Django + DRF + Celery) can be used; the product spec
is intentionally stack‑agnostic.

---

## 🗃️ Data Model

The data model is implemented in SQL under `supabase/migrations/0001_create_schema.sql`.
It defines organizations, users, grants, tracked grants, tasks and integrations.
The schema mirrors the ER diagram in the product specification.

Key tables:

* **orgs** – stores each nonprofit’s metadata (name, allowed states and focus areas,
  secret for calendar feeds, etc.).
* **users** – maps users to organizations with a role (admin or contributor).
* **grants** – stores opportunities imported from Grants.gov or added manually.
* **org_grants** – represents a grant saved by an org.  Tracks stage, priority,
  owner and custom deadlines.
* **tasks** – checklist items attached to a saved grant.
* **integrations** – holds a per‑org Google OAuth refresh token.
* **reminder_jobs** – internal job queue used to dedupe scheduled reminders.

Row level security (RLS) policies are defined in `supabase/policies.sql`.

---

## ✅ Acceptance Criteria (MVP)

* Users can filter and view open federal grants and **save** them.
* Saved grants appear on a pipeline board; stage changes persist.
* Each grant supports multiple deadlines; reminders are scheduled at
  T‑30/14/7/3/1 + T0 and are not duplicated after edits.
* Users can subscribe to an iCalendar feed; Google push (Pro) mirrors
  create/update/delete events.
* Collaboration features: invite teammates, assign owners and create tasks.
* CSV import maps correctly to `org_grants` and deadlines (not yet
  implemented in this scaffold).
* Security: organization data is isolated via RLS and calendar URLs are
  revocable.

---

## 🚀 Quickstart

1. **Install dependencies**

   ```bash
   pnpm install
   # or npm install
   ```

2. **Configure Supabase** – create a new Supabase project and copy your
   project URL and anon/service keys into an `.env` file (see
   `.env.example`).  Run the SQL migrations in `supabase/migrations` via
   Supabase Studio or the CLI.  Apply the policies in `supabase/policies.sql`.

3. **Seed data** (optional) – run the seed script or import the sample SQL in
   `supabase/seed/seed.sql` to generate sample orgs, users and grants.

4. **Start the development server**

   ```bash
   pnpm dev
   # Frontend: http://localhost:3000
   ```

5. **Schedule reminders** – configure Vercel Cron or Supabase Scheduled
   Functions to hit `/api/jobs/reminders` every 15 minutes.

6. **Set up webhooks** – configure Stripe webhooks to post to
   `/api/webhooks/stripe`.  (Email/SMS provider webhooks can be added as
   needed.)

7. **Integrate calendars** – subscribe to the `.ics` feed at
   `/api/orgs/:orgId/calendar.ics?key=...` or complete the Google OAuth flow
   via `/api/integrations/google/callback`.

---

## 🔌 Integrations

This scaffold does not include the actual Grants.gov ingestion logic but
provides a configuration file at `config/grants-gov.json` where you can
specify keyword, category and state filters.  A scheduled job should
periodically fetch opportunities and upsert them into the `grants` table.

Calendar integration is provided through two routes:

* **ICS feed** – `app/api/orgs/[orgId]/calendar.ics/route.ts` generates a
  calendar file for all upcoming deadlines for an organization.  Each
  event uses a stable UID derived from the org grant and milestone type.
* **Google Calendar** – a stub callback route at
  `app/api/integrations/google/callback/route.ts` shows how to store a
  refresh token in the `integrations` table.  You will need to obtain a
  Google API client ID, secret and configure OAuth consent.

Email and SMS templates live under `templates/emails` and `templates/sms`.
The reminder job composes messages using these templates and sends them via
your chosen provider.

---

## 🔐 Security

* **RLS**: All tables scoped to an organization enforce row level security.
  Policies in `supabase/policies.sql` ensure users can only access data
  belonging to their organization.
* **Secrets**: Calendar feed keys are random strings stored per org.  They
  should be stored in your database and never exposed in code.  All other
  secrets (API keys, encryption keys) must be kept in environment variables
  and not committed to the repository.
* **Backups**: Configure automated database backups and test your restore
  runbook.
* **Compliance**: Follow CAN‑SPAM/TCPA for all outbound messaging.

See `docs/security-checklist.md` for a more detailed checklist.

---

## 🛠️ API

Example routes implemented in this scaffold:

```http
GET  /api/grants?state=PA&focus=Youth&dueWithin=60
POST /api/org-grants                  { grantId, stage, ownerUserId }
PATCH /api/org-grants/:id             { stage, notes, priority }
POST /api/org-grants/:id/deadlines    [{ type, date }]
POST /api/org-grants/:id/tasks        { title, dueAt, assigneeId }
GET  /api/orgs/:orgId/calendar.ics?key=...
POST /api/integrations/google/callback
POST /api/checkout/session
POST /api/webhooks/stripe
```

These routes are only skeletons – you will need to fill in business logic,
authentication (Supabase Auth), validation and error handling.  See the
comments inside each `app/api/**/route.ts` file for guidance.

---

## 💳 Plans & Limits

The scaffold does not enforce plan limits.  A sample tier table is provided
below to guide your implementation:

| Plan    | Saved Grants | Users     | Reminders | Calendar | Google Push | SMS  | Price  |
| ------- | ------------ | --------- | --------- | -------- | ----------- | ---- | ------ |
| Free    | 3            | 1         | Email     | ✔        | —           | —    | $0     |
| Starter | 20           | Unlimited | Email     | ✔        | —           | —    | $19/mo |
| Pro     | Unlimited    | Unlimited | Email/SMS | ✔        | ✔           | ✔    | $49/mo |

You can enforce limits in your application code and via database constraints.

---

## 🗺️ Roadmap

* Implement the full Grants.gov ingestion pipeline with nightly fetches and
  incremental updates.
* Add recurring report deadlines using an RRULE editor.
* Provide grant templates for LOI, budget and task checklists.
* Integrate private/foundation data partners for additional grant discovery.
* Build analytics dashboards for submissions, hit rate and funding won.
* Develop admin tools for support and content moderation.

---

## 🤝 Contributing

1. Fork this repository and create a new branch for your feature.
2. Add tests for any new logic (API routes, background jobs, etc.).
3. Run `pnpm lint` and `pnpm typecheck` to ensure code quality.
4. Open a pull request with a concise description and screenshots where
   appropriate.

---

## 🧪 QA Script (happy path)

1. Create an organization and invite two teammates.
2. Discover grants via the `/api/grants` endpoint and save three grants.
3. Set LOI and application deadlines; verify that reminder jobs are queued.
4. Subscribe to the iCalendar feed in Google or Outlook.
5. Connect a Google account (Pro); verify events are pushed to the calendar.
6. Change a deadline and ensure the calendar and reminders update accordingly.
7. Import a CSV file of existing grants; verify deduplication prompts.
8. Upgrade the plan via Stripe; confirm that plan limits are lifted.

---

## 📄 License

The project is currently unlicensed.  Choose your preferred license (MIT,
Apache‑2.0 or proprietary), add it to a `LICENSE` file and update this
section accordingly.

---

## 📬 Support

* **Product owner**: Thomas Darby
* **Contact**: please add a support email or portal.
* **Status page**: optional.

---

### Appendix: Unique Constraint for Reminder De‑dupe

The following SQL snippet (included in the migration) ensures that reminder
jobs are not duplicated when editing deadlines:

```sql
create table reminder_jobs (
  id uuid primary key default gen_random_uuid(),
  org_grant_id uuid not null references org_grants(id) on delete cascade,
  milestone text not null, -- LOI|Application|Report
  send_at timestamptz not null,
  channel text not null,   -- email|sms
  payload jsonb not null,
  status text not null default 'queued' -- queued|sent|failed
);

create unique index ux_reminder_dedupe
  on reminder_jobs(org_grant_id, milestone, send_at, channel);
```