import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

/**
 * API Route: GET /api/orgs/:orgId/calendar.ics
 *
 * Generates an iCalendar feed for all upcoming deadlines associated with the
 * specified organisation.  The `key` query parameter must match the
 * organisation’s `ics_secret`.  This implementation generates a minimal
 * calendar; you may wish to use a dedicated library for production.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: { orgId: string } }
) {
  const orgId = params.orgId;
  const url = new URL(req.url);
  const key = url.searchParams.get('key');

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
  // Verify secret
  const { data: org, error: orgError } = await supabase
    .from('orgs')
    .select('ics_secret, name')
    .eq('id', orgId)
    .single();
  if (orgError || !org) {
    return new NextResponse('Not found', { status: 404 });
  }
  if (!key || key !== org.ics_secret) {
    return new NextResponse('Unauthorized', { status: 401 });
  }
  // Fetch upcoming deadlines for saved grants
  const { data: saved, error: savedError } = await supabase
    .from('org_grants')
    .select('id, custom_deadlines, grants(title)')
    .eq('org_id', orgId);
  if (savedError || !saved) {
    return new NextResponse('Error fetching data', { status: 500 });
  }
  const events: string[] = [];
  let uidCounter = 1;
  saved.forEach((row: any) => {
    const deadlines = row.custom_deadlines || [];
    deadlines.forEach((d: any) => {
      const date = new Date(d.date);
      const uid = `${row.id}-${d.type}-${uidCounter++}@grant-tracker.local`;
      const formattedDate = date
        .toISOString()
        .replace(/[-:]/g, '')
        .split('.')[0] + 'Z';
      events.push(
        `BEGIN:VEVENT\n` +
          `UID:${uid}\n` +
          `DTSTAMP:${formattedDate}\n` +
          `DTSTART;VALUE=DATE:${formattedDate.substring(0, 8)}\n` +
          `SUMMARY:${row.grants.title} — ${d.type} due\n` +
          `END:VEVENT`
      );
    });
  });
  const ics =
    'BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Grant Tracker//EN' +
    '\n' +
    events.join('\n') +
    '\nEND:VCALENDAR';
  return new NextResponse(ics, {
    status: 200,
    headers: { 'Content-Type': 'text/calendar; charset=utf-8' }
  });
}