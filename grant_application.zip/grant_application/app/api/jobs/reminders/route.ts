import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { ReminderEmail } from '../../../templates/emails/reminder';
import { reminderSms } from '../../../templates/sms/reminder';

/**
 * API Route: POST /api/jobs/reminders
 *
 * This endpoint is intended to be called by a cron scheduler every
 * 15 minutes.  It fetches pending reminder jobs whose `send_at` is in the
 * past and sends them via email or SMS.  In this scaffold the actual
 * provider integrations are omitted.  After sending, the job status is
 * updated to 'sent'.
 */
export async function POST(_req: NextRequest) {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  const now = new Date().toISOString();
  const { data: jobs, error } = await supabase
    .from('reminder_jobs')
    .select('*')
    .eq('status', 'queued')
    .lte('send_at', now)
    .limit(50);
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  // Send each job (mocked)
  for (const job of jobs ?? []) {
    try {
      // Retrieve additional context: org, grant, user, deadlines, etc.
      // Compose the message using templates.  In this scaffold we just
      // log the payload.
      console.log('Sending reminder', job);
      // TODO: send via email or SMS using the configured provider
      await supabase
        .from('reminder_jobs')
        .update({ status: 'sent' })
        .eq('id', job.id);
    } catch (e) {
      await supabase
        .from('reminder_jobs')
        .update({ status: 'failed' })
        .eq('id', job.id);
    }
  }
  return NextResponse.json({ processed: jobs?.length ?? 0 });
}