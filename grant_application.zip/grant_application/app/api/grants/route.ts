import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

/**
 * API Route: GET /api/grants
 *
 * Returns a list of federal grant opportunities filtered by state, focus area and
 * due date.  This implementation is a stub – it connects to Supabase and
 * queries the `grants` table.  In production you would add pagination,
 * authentication and more robust filtering.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const state = url.searchParams.get('state');
  const focus = url.searchParams.get('focus');
  const dueWithin = url.searchParams.get('dueWithin');

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  let query = supabase.from('grants').select('*');
  if (state) {
    query = query.contains('geography', [state]);
  }
  if (focus) {
    query = query.contains('category', [focus]);
  }
  if (dueWithin) {
    const days = parseInt(dueWithin, 10);
    if (!Number.isNaN(days)) {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() + days);
      query = query.lte('close_date', cutoff.toISOString().slice(0, 10));
    }
  }

  const { data, error } = await query.order('close_date', { ascending: true });
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data ?? []);
}