import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

/**
 * API Route: POST /api/integrations/google/callback
 *
 * Handles the OAuth callback from Google Calendar.  The request body should
 * contain the `code` parameter returned by Google as well as the `state`
 * parameter encoding the organisation ID and user ID.  This stub does not
 * perform the actual token exchange – you will need to call Google’s OAuth
 * token endpoint to obtain an access token and refresh token.
 */
export async function POST(req: NextRequest) {
  const { code, state } = await req.json();
  if (!code || !state) {
    return NextResponse.json(
      { error: 'Missing code or state' },
      { status: 400 }
    );
  }
  // In a real implementation, decode the state (e.g. JSON.stringify({ orgId, userId }))
  // then exchange the code for tokens at https://oauth2.googleapis.com/token.
  // For now we simulate storing a dummy refresh token.
  let orgId: string;
  try {
    const parsed = JSON.parse(Buffer.from(state, 'base64').toString('utf8'));
    orgId = parsed.orgId;
  } catch (e) {
    return NextResponse.json(
      { error: 'Invalid state parameter' },
      { status: 400 }
    );
  }
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  const dummyRefreshToken = 'DUMMY_REFRESH_TOKEN';
  const { error } = await supabase
    .from('integrations')
    .upsert({ org_id: orgId, google_refresh_token: dummyRefreshToken });
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json({ success: true });
}