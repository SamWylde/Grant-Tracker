import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

/**
 * API Route: POST /api/checkout/session
 *
 * Creates a Stripe checkout session for upgrading plans.  The request body
 * should specify the price ID (e.g. from environment variables) and the
 * organisation ID for which the checkout is being created.  This stub
 * assumes Stripe is configured via environment variables.
 */
export async function POST(req: NextRequest) {
  const { priceId, orgId, successUrl, cancelUrl } = await req.json();
  if (!priceId || !orgId) {
    return NextResponse.json(
      { error: 'priceId and orgId are required' },
      { status: 400 }
    );
  }
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: '2023-08-16'
  });
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1
        }
      ],
      success_url: successUrl ?? `${process.env.NEXT_PUBLIC_SITE_URL}/billing/success`,
      cancel_url: cancelUrl ?? `${process.env.NEXT_PUBLIC_SITE_URL}/billing/cancel`,
      metadata: { orgId }
    });
    return NextResponse.json({ id: session.id });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}