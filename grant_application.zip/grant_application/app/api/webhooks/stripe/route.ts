import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

// Stripe requires raw body for webhook verification.  Next.js (App Router)
// supports this by exporting a configuration object.
export const config = {
  api: {
    bodyParser: false
  }
};

/**
 * API Route: POST /api/webhooks/stripe
 *
 * Handles incoming Stripe webhook events.  Verifies the signature using
 * STRIPE_WEBHOOK_SECRET and updates subscription status accordingly.  This
 * stub does not persist anything but logs the event type for reference.
 */
export async function POST(req: NextRequest) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: '2023-08-16'
  });
  const sig = req.headers.get('stripe-signature');
  if (!sig) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 });
  }
  const buf = await req.arrayBuffer();
  const rawBody = Buffer.from(buf);
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 });
  }
  // TODO: handle subscription events and update plan limits for the org
  console.log('Received Stripe event', event.type);
  return new NextResponse('OK', { status: 200 });
}