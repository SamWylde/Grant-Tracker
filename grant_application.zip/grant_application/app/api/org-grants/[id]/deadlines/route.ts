import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

/**
 * API Route: POST /api/org-grants/:id/deadlines
 *
 * Accepts an array of objects `{ type, date }` representing LOI,
 * Application and Report deadlines.  The dates should be in ISO format.
 * The implementation here simply stores the array as JSON in the
 * `custom_deadlines` column of the org_grants table.  Real logic would
 * also schedule reminder jobs based on these dates.
 */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const id = params.id;
  const deadlines = await req.json();
  if (!Array.isArray(deadlines)) {
    return NextResponse.json(
      { error: 'Expected an array of deadlines' },
      { status: 400 }
    );
  }
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  const { data, error } = await supabase
    .from('org_grants')
    .update({ custom_deadlines: deadlines })
    .eq('id', id)
    .select('*')
    .single();
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  // TODO: enqueue reminders for each milestone via reminder_jobs table
  return NextResponse.json(data);
}