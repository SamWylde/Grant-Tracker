import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

/**
 * API Route: POST /api/org-grants/:id/tasks
 *
 * Creates a new task for a saved grant.  Required fields: `title` and
 * `dueAt`.  Optionally specify `assigneeId`.  The user creating the task
 * should have permission to update the given org_grant.
 */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const orgGrantId = params.id;
  const { title, dueAt, assigneeId } = await req.json();
  if (!title || !dueAt) {
    return NextResponse.json(
      { error: 'title and dueAt are required' },
      { status: 400 }
    );
  }
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  const { data, error } = await supabase.from('tasks').insert({
    org_grant_id: orgGrantId,
    title,
    due_at: dueAt,
    assignee_id: assigneeId ?? null
  });
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data[0], { status: 201 });
}