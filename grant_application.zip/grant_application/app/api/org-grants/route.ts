import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

/**
 * API Route: /api/org-grants
 *
 * Supports GET and POST.  This is a simplified example; in a real application
 * you would enforce authentication, validate input, check plan limits and
 * ensure the user belongs to the organisation in question.
 */
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const orgId = url.searchParams.get('orgId');
  if (!orgId) {
    return NextResponse.json({ error: 'orgId is required' }, { status: 400 });
  }
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
  const { data, error } = await supabase
    .from('org_grants')
    .select('*')
    .eq('org_id', orgId);
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data ?? []);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { orgId, grantId, stage = 'researching', ownerUserId, notes, priority } =
    body;
  if (!orgId || !grantId) {
    return NextResponse.json(
      { error: 'orgId and grantId are required' },
      { status: 400 }
    );
  }
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  const { data, error } = await supabase.from('org_grants').insert({
    org_id: orgId,
    grant_id: grantId,
    stage,
    owner_user_id: ownerUserId ?? null,
    notes: notes ?? null,
    priority: priority ?? null
  });
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data[0], { status: 201 });
}