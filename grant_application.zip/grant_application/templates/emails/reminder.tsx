import React from 'react';

interface ReminderEmailProps {
  orgName: string;
  grantTitle: string;
  milestone: string;
  dueDate: Date;
  daysRemaining: number;
  unsubscribeUrl: string;
}

/**
 * Renders an HTML email reminding a user of an upcoming grant milestone.
 * Use a library such as @sendgrid/mail or postmark to send the
 * rendered HTML content.  The dates should be preformatted using the
 * organisation’s timezone.
 */
export function ReminderEmail({
  orgName,
  grantTitle,
  milestone,
  dueDate,
  daysRemaining,
  unsubscribeUrl
}: ReminderEmailProps) {
  return (
    <html>
      <body style={{ fontFamily: 'sans-serif', lineHeight: 1.5 }}>
        <h2>{orgName}</h2>
        <p>
          <strong>{grantTitle}</strong> — {milestone} is due in {daysRemaining}{' '}
          days on {dueDate.toLocaleDateString()}.
        </p>
        <p>
          Please log in to the Grant Application Tracker to review your tasks
          and update your submission status.
        </p>
        <p>
          <a href={unsubscribeUrl}>Unsubscribe or manage preferences</a>
        </p>
      </body>
    </html>
  );
}