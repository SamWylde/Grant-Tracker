/**
 * Composes an SMS reminder message.
 * Providers such as Twilio can send plain text messages constructed
 * with this function.  Keep the message under 160 characters when
 * possible to avoid splitting.
 */
export function reminderSms(grantTitle: string, milestone: string, daysRemaining: number, dueDate: Date) {
  return `Due in ${daysRemaining} days: ${grantTitle} — ${milestone} on ${dueDate.toLocaleDateString()}. Reply STOP to unsubscribe.`;
}