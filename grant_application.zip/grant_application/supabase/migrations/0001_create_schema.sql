-- Grant Application Tracker schema

-- Enable extensions for UUID generation
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- Organizations
create table if not exists orgs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  state_codes text[] not null default '{}',
  focus_areas text[] not null default '{}',
  ics_secret text not null,
  created_at timestamptz not null default now()
);

-- Users
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references orgs(id) on delete cascade,
  role text not null check (role in ('admin','contributor')),
  email text not null,
  name text not null,
  created_at timestamptz not null default now()
);

-- Grants
create table if not exists grants (
  id uuid primary key default gen_random_uuid(),
  source text not null check (source in ('grants_gov','manual')),
  external_id text not null,
  title text not null,
  sponsor text,
  url text,
  summary text,
  amount_min numeric,
  amount_max numeric,
  geography text[] not null default '{}',
  category text[] not null default '{}',
  close_date date,
  deadlines_json jsonb,
  created_at timestamptz not null default now(),
  unique (source, external_id)
);

-- ORG_GRANTS – grants saved by an organization
create table if not exists org_grants (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references orgs(id) on delete cascade,
  grant_id uuid not null references grants(id) on delete cascade,
  stage text not null check (stage in ('researching','drafting','submitted','awarded','declined')) default 'researching',
  priority integer,
  owner_user_id uuid references users(id) on delete set null,
  notes text,
  custom_deadlines jsonb,
  created_at timestamptz not null default now(),
  unique (org_id, grant_id)
);

-- Tasks attached to a saved grant
create table if not exists tasks (
  id uuid primary key default gen_random_uuid(),
  org_grant_id uuid not null references org_grants(id) on delete cascade,
  title text not null,
  due_at timestamptz not null,
  assignee_id uuid references users(id) on delete set null,
  status text not null check (status in ('todo','doing','done')) default 'todo',
  created_at timestamptz not null default now()
);

-- Google integrations (per org)
create table if not exists integrations (
  org_id uuid primary key references orgs(id) on delete cascade,
  google_refresh_token text
);

-- Reminder job queue used for deduplication
create table if not exists reminder_jobs (
  id uuid primary key default gen_random_uuid(),
  org_grant_id uuid not null references org_grants(id) on delete cascade,
  milestone text not null, -- LOI | Application | Report
  send_at timestamptz not null,
  channel text not null,   -- email | sms
  payload jsonb not null,
  status text not null default 'queued'
);

create unique index if not exists ux_reminder_dedupe
  on reminder_jobs(org_grant_id, milestone, send_at, channel);