-- Sample seed data for Grant Application Tracker

insert into orgs (id, name, state_codes, focus_areas, ics_secret)
values
  ('00000000-0000-0000-0000-000000000001', 'Example Nonprofit', '{PA}', '{Youth}', 'secretkey');

insert into users (id, org_id, role, email, name)
values
  ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-000000000001', 'admin', 'alice@example.org', 'Alice Admin'),
  ('00000000-0000-0000-0000-000000000102', '00000000-0000-0000-0000-000000000001', 'contributor', 'bob@example.org', 'Bob Contributor');

-- Example grants imported from Grants.gov
insert into grants (id, source, external_id, title, sponsor, url, summary, amount_min, amount_max, geography, category, close_date)
values
  ('10000000-0000-0000-0000-000000000001', 'grants_gov', '12345', 'Youth Development Program', 'Dept. of Education', 'https://example.gov/grants/12345', 'Support for community youth programs.', 5000, 20000, '{PA}', '{Youth}', '2025-12-31');

-- An org saving the example grant
insert into org_grants (id, org_id, grant_id, stage, priority, owner_user_id, notes)
values
  ('20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'researching', 1, '00000000-0000-0000-0000-000000000101', 'Initial research started');

-- A couple of tasks for the saved grant
insert into tasks (id, org_grant_id, title, due_at, assignee_id, status)
values
  ('30000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000001', 'Prepare outline', now() + interval '7 days', '00000000-0000-0000-0000-000000000102', 'todo'),
  ('30000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000001', 'Collect letters of support', now() + interval '14 days', null, 'todo');