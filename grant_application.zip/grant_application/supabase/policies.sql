-- Row level security policies for Grant Application Tracker

-- Enable RLS on all organisation scoped tables
alter table orgs enable row level security;
alter table users enable row level security;
alter table grants enable row level security;
alter table org_grants enable row level security;
alter table tasks enable row level security;
alter table integrations enable row level security;
alter table reminder_jobs enable row level security;

-- Example policy: users can read their own organisation
create policy "orgs_read" on orgs for select using (
  auth.uid() is not null and id = auth.role()::uuid
);

-- Example policy: users can see and manage data for their organisation
-- (Replace with more granular policies in production.)
create policy "org_data" on users for all using (
  auth.uid() is not null and org_id = auth.role()::uuid
);

-- Additional policies should be added here to restrict insert,
-- update and delete permissions as appropriate.  See the Supabase
-- documentation for examples: https://supabase.com/docs/.