# Security Checklist

This document enumerates a non‑exhaustive list of tasks to help ensure that
the Grant Application Tracker meets baseline security expectations.  Treat
these as starting points and adapt them to your specific infrastructure and
compliance requirements.

## Authentication & Authorization

* Use Supabase Auth with email/password or single‑sign‑on providers.
* Enforce unique emails across users and verify email addresses.
* Use row level security (RLS) on all organisation‑scoped tables.  Users
  should only be able to access data where `users.org_id = orgs.id`.
* Implement role checks for admin‑only actions (inviting users, deleting data,
  revoking calendar secrets).

## Secrets & Config

* Store all API keys and secrets in environment variables (e.g. via
  Vercel/Supabase secrets).  Never commit secrets to source control.
* Generate an `ics_secret` per organisation using a high‑entropy random
  string.  Provide a mechanism to revoke and regenerate the secret.
* Use an encryption key to encrypt OAuth refresh tokens in the database.
* Rotate API credentials regularly and monitor for unauthorized usage.

## Data Protection

* Encrypt data at rest (Postgres and object storage) and in transit (HTTPS).
* Take daily automated backups of the database.  Regularly test restoring
  from backups.
* Set retention policies for backups (e.g. 14 days minimum).
* Consider anonymizing logs where possible to avoid storing personal data.

## Communications

* Comply with CAN‑SPAM/TCPA for all outbound email and SMS messages.
* Include an unsubscribe or preferences link in every email.  Handle
  unsubscribe requests promptly.
* Respect user notification preferences stored in your database.

## Webhooks & APIs

* Verify signatures on incoming Stripe webhooks before processing.
* Rate limit API endpoints to prevent abuse.
* Validate and sanitize all user input to prevent injection attacks.
* Return generic error messages to avoid leaking sensitive information.

## Monitoring & Auditing

* Enable logging of authentication events and critical actions (e.g. grant
  creation, deletion, role changes).
* Integrate with an observability platform (Sentry, PostHog) for real‑time
  error reporting and analytics.
* Periodically review logs for suspicious activity and implement alerts for
  anomalies (e.g. repeated failed login attempts).

## Deployment

* Use HTTPS everywhere.  Enforce HSTS and other security headers via your
  hosting platform.
* Keep dependencies up to date and monitor for vulnerabilities with tools
  like `npm audit` or Snyk.
* Follow the principle of least privilege when provisioning cloud resources.

---

This checklist should evolve as the project matures and new threats emerge.
Regular security reviews and audits are essential to maintain a secure
application.